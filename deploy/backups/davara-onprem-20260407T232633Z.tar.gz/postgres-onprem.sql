--
-- PostgreSQL database dump
--

\restrict Z2Iaq9dnU8liMUnawlOgNRkIgCrBROGScTW87vex1DSI2m2ECmai9y40njEB9OV

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.idx_sync_operations_created_at;
DROP INDEX IF EXISTS public.idx_sync_conflicts_status;
DROP INDEX IF EXISTS public.idx_security_events_created_at;
DROP INDEX IF EXISTS public.idx_record_versions_record;
DROP INDEX IF EXISTS public.idx_module_records_updated_at;
DROP INDEX IF EXISTS public.idx_module_records_module;
DROP INDEX IF EXISTS public.idx_audit_events_created_at;
ALTER TABLE IF EXISTS ONLY public.sync_operations DROP CONSTRAINT IF EXISTS sync_operations_pkey;
ALTER TABLE IF EXISTS ONLY public.sync_operations DROP CONSTRAINT IF EXISTS sync_operations_operation_key_key;
ALTER TABLE IF EXISTS ONLY public.sync_conflicts DROP CONSTRAINT IF EXISTS sync_conflicts_pkey;
ALTER TABLE IF EXISTS ONLY public.security_events DROP CONSTRAINT IF EXISTS security_events_pkey;
ALTER TABLE IF EXISTS ONLY public.record_versions DROP CONSTRAINT IF EXISTS record_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.onprem_users DROP CONSTRAINT IF EXISTS onprem_users_pkey;
ALTER TABLE IF EXISTS ONLY public.onprem_users DROP CONSTRAINT IF EXISTS onprem_users_email_key;
ALTER TABLE IF EXISTS ONLY public.onprem_sessions DROP CONSTRAINT IF EXISTS onprem_sessions_session_token_key;
ALTER TABLE IF EXISTS ONLY public.onprem_sessions DROP CONSTRAINT IF EXISTS onprem_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.onprem_devices DROP CONSTRAINT IF EXISTS onprem_devices_pkey;
ALTER TABLE IF EXISTS ONLY public.onprem_devices DROP CONSTRAINT IF EXISTS onprem_devices_device_key_key;
ALTER TABLE IF EXISTS ONLY public.module_records DROP CONSTRAINT IF EXISTS module_records_pkey;
ALTER TABLE IF EXISTS ONLY public.module_records DROP CONSTRAINT IF EXISTS module_records_module_key_record_key_key;
ALTER TABLE IF EXISTS ONLY public.backup_runs DROP CONSTRAINT IF EXISTS backup_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_events DROP CONSTRAINT IF EXISTS audit_events_pkey;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_pkey;
ALTER TABLE IF EXISTS public.security_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.record_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backup_runs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_events ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.sync_operations;
DROP TABLE IF EXISTS public.sync_conflicts;
DROP SEQUENCE IF EXISTS public.security_events_id_seq;
DROP TABLE IF EXISTS public.security_events;
DROP SEQUENCE IF EXISTS public.record_versions_id_seq;
DROP TABLE IF EXISTS public.record_versions;
DROP TABLE IF EXISTS public.onprem_users;
DROP TABLE IF EXISTS public.onprem_sessions;
DROP TABLE IF EXISTS public.onprem_devices;
DROP TABLE IF EXISTS public.module_records;
DROP SEQUENCE IF EXISTS public.backup_runs_id_seq;
DROP TABLE IF EXISTS public.backup_runs;
DROP SEQUENCE IF EXISTS public.audit_events_id_seq;
DROP TABLE IF EXISTS public.audit_events;
DROP TABLE IF EXISTS public.attachments;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_key text NOT NULL,
    record_key text NOT NULL,
    filename text NOT NULL,
    content_type text NOT NULL,
    byte_size bigint DEFAULT 0 NOT NULL,
    sha256 text,
    storage_path text NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id bigint NOT NULL,
    event_type text NOT NULL,
    actor_email text,
    details text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_events_id_seq OWNED BY public.audit_events.id;


--
-- Name: backup_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_runs (
    id bigint NOT NULL,
    archive_name text NOT NULL,
    status text NOT NULL,
    manifest jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backup_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backup_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backup_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backup_runs_id_seq OWNED BY public.backup_runs.id;


--
-- Name: module_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_key text NOT NULL,
    record_key text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    updated_by text,
    device_key text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: onprem_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onprem_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    device_key text NOT NULL,
    label text NOT NULL,
    actor_email text NOT NULL,
    last_ip text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: onprem_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onprem_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_token text NOT NULL,
    actor_email text NOT NULL,
    device_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: onprem_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onprem_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    full_name text NOT NULL,
    role_name text DEFAULT 'admin'::text NOT NULL,
    approved boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: record_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.record_versions (
    id bigint NOT NULL,
    module_key text NOT NULL,
    record_key text NOT NULL,
    version integer NOT NULL,
    payload jsonb NOT NULL,
    operation_type text NOT NULL,
    actor_email text,
    device_key text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: record_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.record_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: record_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.record_versions_id_seq OWNED BY public.record_versions.id;


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_events (
    id bigint NOT NULL,
    category text NOT NULL,
    severity text NOT NULL,
    message text NOT NULL,
    actor_email text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: security_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_events_id_seq OWNED BY public.security_events.id;


--
-- Name: sync_conflicts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_conflicts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_key text NOT NULL,
    record_key text NOT NULL,
    local_payload jsonb NOT NULL,
    remote_payload jsonb NOT NULL,
    local_base_version integer NOT NULL,
    remote_version integer NOT NULL,
    actor_email text,
    device_key text,
    status text DEFAULT 'open'::text NOT NULL,
    resolution_payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


--
-- Name: sync_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sync_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    operation_key text NOT NULL,
    device_key text NOT NULL,
    module_key text NOT NULL,
    record_key text NOT NULL,
    operation_type text NOT NULL,
    base_version integer DEFAULT 0 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    actor_email text,
    status text DEFAULT 'received'::text NOT NULL,
    detail jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events ALTER COLUMN id SET DEFAULT nextval('public.audit_events_id_seq'::regclass);


--
-- Name: backup_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_runs ALTER COLUMN id SET DEFAULT nextval('public.backup_runs_id_seq'::regclass);


--
-- Name: record_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_versions ALTER COLUMN id SET DEFAULT nextval('public.record_versions_id_seq'::regclass);


--
-- Name: security_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events ALTER COLUMN id SET DEFAULT nextval('public.security_events_id_seq'::regclass);


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, module_key, record_key, filename, content_type, byte_size, sha256, storage_path, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, event_type, actor_email, details, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: backup_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_runs (id, archive_name, status, manifest, created_at) FROM stdin;
\.


--
-- Data for Name: module_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.module_records (id, module_key, record_key, version, payload, deleted, updated_by, device_key, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: onprem_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onprem_devices (id, device_key, label, actor_email, last_ip, created_at, last_seen_at) FROM stdin;
\.


--
-- Data for Name: onprem_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onprem_sessions (id, session_token, actor_email, device_key, created_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: onprem_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onprem_users (id, email, full_name, role_name, approved, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: record_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.record_versions (id, module_key, record_key, version, payload, operation_type, actor_email, device_key, created_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_events (id, category, severity, message, actor_email, metadata, created_at) FROM stdin;
1	deployment	info	Esquema on-premise inicializado para sincronización híbrida y evidencia central	system@bootstrap.local	{"source": "001_onprem_core.sql"}	2026-04-07 23:25:37.434195+00
\.


--
-- Data for Name: sync_conflicts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_conflicts (id, module_key, record_key, local_payload, remote_payload, local_base_version, remote_version, actor_email, device_key, status, resolution_payload, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: sync_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sync_operations (id, operation_key, device_key, module_key, record_key, operation_type, base_version, payload, actor_email, status, detail, created_at) FROM stdin;
\.


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_events_id_seq', 1, false);


--
-- Name: backup_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backup_runs_id_seq', 1, false);


--
-- Name: record_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.record_versions_id_seq', 1, false);


--
-- Name: security_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.security_events_id_seq', 1, true);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: backup_runs backup_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_runs
    ADD CONSTRAINT backup_runs_pkey PRIMARY KEY (id);


--
-- Name: module_records module_records_module_key_record_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_records
    ADD CONSTRAINT module_records_module_key_record_key_key UNIQUE (module_key, record_key);


--
-- Name: module_records module_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_records
    ADD CONSTRAINT module_records_pkey PRIMARY KEY (id);


--
-- Name: onprem_devices onprem_devices_device_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onprem_devices
    ADD CONSTRAINT onprem_devices_device_key_key UNIQUE (device_key);


--
-- Name: onprem_devices onprem_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onprem_devices
    ADD CONSTRAINT onprem_devices_pkey PRIMARY KEY (id);


--
-- Name: onprem_sessions onprem_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onprem_sessions
    ADD CONSTRAINT onprem_sessions_pkey PRIMARY KEY (id);


--
-- Name: onprem_sessions onprem_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onprem_sessions
    ADD CONSTRAINT onprem_sessions_session_token_key UNIQUE (session_token);


--
-- Name: onprem_users onprem_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onprem_users
    ADD CONSTRAINT onprem_users_email_key UNIQUE (email);


--
-- Name: onprem_users onprem_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onprem_users
    ADD CONSTRAINT onprem_users_pkey PRIMARY KEY (id);


--
-- Name: record_versions record_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.record_versions
    ADD CONSTRAINT record_versions_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: sync_conflicts sync_conflicts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_conflicts
    ADD CONSTRAINT sync_conflicts_pkey PRIMARY KEY (id);


--
-- Name: sync_operations sync_operations_operation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_operations
    ADD CONSTRAINT sync_operations_operation_key_key UNIQUE (operation_key);


--
-- Name: sync_operations sync_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sync_operations
    ADD CONSTRAINT sync_operations_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_events_created_at ON public.audit_events USING btree (created_at DESC);


--
-- Name: idx_module_records_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_module_records_module ON public.module_records USING btree (module_key, record_key);


--
-- Name: idx_module_records_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_module_records_updated_at ON public.module_records USING btree (updated_at DESC);


--
-- Name: idx_record_versions_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_record_versions_record ON public.record_versions USING btree (module_key, record_key, version DESC);


--
-- Name: idx_security_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_created_at ON public.security_events USING btree (created_at DESC);


--
-- Name: idx_sync_conflicts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_conflicts_status ON public.sync_conflicts USING btree (status, created_at DESC);


--
-- Name: idx_sync_operations_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sync_operations_created_at ON public.sync_operations USING btree (created_at DESC);


--
-- PostgreSQL database dump complete
--

\unrestrict Z2Iaq9dnU8liMUnawlOgNRkIgCrBROGScTW87vex1DSI2m2ECmai9y40njEB9OV

